/* xli trailing option header file */

#define TOBUFSZ 1024

/* Magic number */
#define KEY "XXX xloadimage trailing options XXX"
