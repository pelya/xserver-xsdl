
#ifndef COMPAT_H
#define COMPAT_H 1

extern LookupEntry groupNames[];

#endif /* COMPAT_H */
